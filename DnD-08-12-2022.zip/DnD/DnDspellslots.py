# Set the character's name
name = "Player"

# Set the character's spell slots
first_level_spell_slots = 2
second_level_spell_slots = 1

# Set the character's spells known
spells = ["magic missile", "cure wounds", "shield"]

# Print the character's name and spell slots
print(f"{name} has {first_level_spell_slots} first level spell slots and {second_level_spell_slots} second level spell slots.")

# Print the character's spells known
print(f"{name} knows the following spells:")
for spell in spells:
    print(f" - {spell}")

# Prompt the user for the name of a spell to cast
spell_name = input("Enter the name of the spell to cast: ")

# Check if the character knows the specified spell
if spell_name not in spells:
    print(f"{name} does not know the spell {spell_name}.")
else:
    # Check if the character has sufficient spell slots to cast the spell
    if spell_name == "magic missile" and first_level_spell_slots > 0:
        # Cast the spell and reduce the number of spell slots
        print(f"{name} casts {spell_name}.")
        first_level_spell_slots -= 1
    elif spell_name == "cure wounds" and second_level_spell_slots > 0:
        # Cast the spell and reduce the number of spell slots
        print(f"{name} casts {spell_name}.")
        second_level_spell_slots -= 1
    elif spell_name == "shield" and first_level_spell_slots > 0:
        # Cast the spell and reduce the number of spell slots
        print(f"{name} casts {spell_name}.")
        first_level_spell_slots -= 1
    else:
        # The character doesn't have enough spell slots
        print(f"{name} does not have enough spell slots to cast {spell_name}.")

# Print the character's remaining spell slots
print(f"{name} has {first_level_spell_slots} first level spell slots and {second_level_spell_slots} second level spell slots remaining.")
