# Set the name of the character and their hit points
name = "Player"
hit_points = 20

# Print the character's name and hit points
print(f"{name} has {hit_points} hit points.")

# Prompt the user for the amount of damage taken
damage = int(input("Enter the amount of damage taken: "))

# Calculate the character's new hit points
hit_points -= damage

# Print the character's new hit points
print(f"{name} takes {damage} points of damage and now has {hit_points} hit points.")

# Prompt the user for the amount of healing received
healing = int(input("Enter the amount of healing received: "))

# Calculate the character's new hit points
hit_points += healing

# Print the character's new hit points
print(f"{name} heals for {healing} points and now has {hit_points} hit points.")

# Set the character's starting position
x = 0
y = 0

# Print the character's starting position
print(f"{name} is at position ({x}, {y}).")

# Prompt the user for the amount of movement in the x and y directions
dx = int(input("Enter the movement in the x direction: "))
dy = int(input("Enter the movement in the y direction: "))

# Update the character's position
x += dx
y += dy

# Print the character's new position
print(f"{name} is at position ({x}, {y}).")