# Define a Character class to represent a D&D character
class Character:
  def __init__(self, name, race, classs, level, hp, strength, dexterity, constitution, intelligence, wisdom, charisma):
    self.name = name
    self.race = race
    self.classs = classs
    self.level = level
    self.hp = hp
    self.stats = {
      "strength": strength,
      "dexterity": dexterity,
      "constitution": constitution,
      "intelligence": intelligence,
      "wisdom": wisdom,
      "charisma": charisma
    }

  # Define a method to calculate the character's attack bonus
  def attack_bonus(self):
    return self.stats["strength"] // 2 + self.level

  # Define a method to calculate the character's damage bonus
  def damage_bonus(self):
    return self.stats["strength"] // 2

  # Define a method to calculate the character's armor class
  def armor_class(self):
    return 10 + self.stats["dexterity"] // 2 + self.stats["constitution"] // 2

  # Define a method to calculate the character's saving throws
  def saving_throws(self):
    return {
      "strength": self.stats["strength"] // 3 + self.level,
      "dexterity": self.stats["dexterity"] // 3 + self.level,
      "constitution": self.stats["constitution"] // 3 + self.level,
      "intelligence": self.stats["intelligence"] // 3 + self.level,
      "wisdom": self.stats["wisdom"] // 3 + self.level,
      "charisma": self.stats["charisma"] // 3 + self.level
    }

  # Define a method to calculate the character's skill bonuses
  def skills(self):
    return {
      "athletics": self.stats["strength"] // 3 + self.level,
      "acrobatics": self.stats["dexterity"] // 3 + self.level,
      "sleight_of_hand": self.stats["dexterity"] // 3 + self.level,
      "stealth": self.stats["dexterity"] // 3 + self.level,
      "arcana": self.stats["intelligence"] // 3 + self.level,
      "history": self.stats["intelligence"] // 3 + self.level,
      "investigation": self.stats["intelligence"] // 3 + self.level,
      "nature": self.stats["intelligence"] // 3 + self.level,
      "religion": self.stats["intelligence"] // 3 + self.level,
      "animal_handling": self.stats["wisdom"] // 3 + self.level,
      "insight": self.stats["wisdom"] // 3 + self.level,
      "medicine": self.stats["wisdom"] // 3 + self.level,
      "perception": self.stats["wisdom"] // 3 + self.level,
    }
